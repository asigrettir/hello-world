﻿using System.Windows.Forms;

namespace AutoClicker.Controls
{
    public class ValueCheckBox : CheckBox
    {
        public string Value { get; set; }
    }
}
